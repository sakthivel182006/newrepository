package com.examly.springapp.controller;

import com.examly.springapp.model.User;
import com.examly.springapp.repository.UserRepository;
import com.examly.springapp.service.UserService;
import jakarta.mail.MessagingException;
import lombok.RequiredArgsConstructor;

import java.util.Optional;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class UserController {


private final UserRepository userRepository;

private final UserService userService;

@PostMapping("/register")
public ResponseEntity<?> registerUser(@RequestBody User user) {
try {
User saved = userService.registerUser(user);
return ResponseEntity.ok("Registration successful! Verification email sent.");
} catch (MessagingException e) {
return ResponseEntity.internalServerError().body("Failed to send email.");
}
}

@GetMapping("/verify")
public ResponseEntity<String> verifyEmail(@RequestParam("token") String token) {
boolean verified = userService.verifyToken(token);
return verified
? ResponseEntity.ok("Email verified successfully!")
: ResponseEntity.badRequest().body("Invalid or expired token.");
}


@PostMapping("/login")
public ResponseEntity<?> loginUser(@RequestParam String email, @RequestParam String password) {
Optional<User> optionalUser = userRepository.findByEmail(email);

if (optionalUser.isPresent()) {
User user = optionalUser.get();

if (user.getPassword().equals(password)) {

if (user.isVerified()) {
return ResponseEntity.ok(user); // user is returned as JSON
} else {
return ResponseEntity.status(403).body("User not verified");
}

} else {
return ResponseEntity.status(401).body("Invalid password");
}
} else {
return ResponseEntity.status(404).body("User not found");
}
}
}