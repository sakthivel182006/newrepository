package com.examly.springapp.enumclass;

public enum UserRole {
    CUSTOMER,
    ADMIN,AGENT
}
