package com.examly.springapp.enumclass;

public enum ClaimStatus {
SUBMITTED,
IN_REVIEW,
APPROVED,
REJECTED
}
