package com.examly.springapp.repository;

import com.examly.springapp.model.ClaimTypes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClaimTypesRepository extends JpaRepository<ClaimTypes, Long> {
}
