const BASE_URL = "https://8080-cbaacefbecfdaacedbdfdaffabfbdede.premiumproject.examly.io";
export default BASE_URL;
