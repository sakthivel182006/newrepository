import React from 'react';

const Home = () => (
<div>
<h1>Insurance Claim Processing System</h1>
<p>Use the menu above to manage customers and claims.</p>
</div>
);

export default Home;
